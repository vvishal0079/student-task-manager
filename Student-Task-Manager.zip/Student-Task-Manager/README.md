# Student Task Manager

A simple student task management web application.

## Features
- Add tasks
- Mark tasks as completed
- Delete tasks
- Search tasks
- Filter All / Pending / Completed
- Task data is saved using browser LocalStorage

## How to Run
Open `index.html` in any modern web browser.

## Technologies
- HTML5
- CSS3
- JavaScript
- LocalStorage

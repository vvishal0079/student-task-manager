let tasks = JSON.parse(localStorage.getItem("studentTasks") || "[]");
let currentFilter = "all";

const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const empty = document.getElementById("empty");
const searchInput = document.getElementById("searchInput");

function save() {
  localStorage.setItem("studentTasks", JSON.stringify(tasks));
}

function addTask() {
  const text = taskInput.value.trim();
  if (!text) return;
  tasks.unshift({ id: Date.now(), text, completed: false });
  taskInput.value = "";
  save();
  render();
  taskInput.focus();
}

function toggleTask(id) {
  tasks = tasks.map(t => t.id === id ? {...t, completed: !t.completed} : t);
  save(); render();
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  save(); render();
}

function render() {
  const query = searchInput.value.toLowerCase().trim();
  const filtered = tasks.filter(t => {
    const matchesFilter =
      currentFilter === "all" ||
      (currentFilter === "completed" && t.completed) ||
      (currentFilter === "pending" && !t.completed);
    return matchesFilter && t.text.toLowerCase().includes(query);
  });

  taskList.innerHTML = "";
  empty.style.display = filtered.length ? "none" : "block";

  filtered.forEach(t => {
    const li = document.createElement("li");
    li.className = "task" + (t.completed ? " done" : "");
    li.innerHTML = `
      <input type="checkbox" ${t.completed ? "checked" : ""} aria-label="Complete task">
      <span>${escapeHtml(t.text)}</span>
      <button class="delete">Delete</button>
    `;
    li.querySelector("input").addEventListener("change", () => toggleTask(t.id));
    li.querySelector(".delete").addEventListener("click", () => deleteTask(t.id));
    taskList.appendChild(li);
  });

  document.getElementById("total").textContent = tasks.length;
  document.getElementById("pending").textContent = tasks.filter(t => !t.completed).length;
  document.getElementById("completed").textContent = tasks.filter(t => t.completed).length;
}

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

document.getElementById("addBtn").addEventListener("click", addTask);
taskInput.addEventListener("keydown", e => { if (e.key === "Enter") addTask(); });
searchInput.addEventListener("input", render);

document.querySelectorAll(".filter").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentFilter = btn.dataset.filter;
    render();
  });
});

render();
